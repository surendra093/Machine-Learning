
--------------------------------------------------------

                    README FILE
--------------------------------------------------------

1) For the file "part1&2.py" you should give the value of degree as input i.e which degree polynomial you to run.
   when you gives the input it gives PARAMETER VALUES,TRAIN ERROR AND TEST ERROR,PLOT FITTING THE TRAINING DATA as output.

2) For the file "error_plot_without regulrization.py" no input is required.It just gives the output of difference of train error
   and test error for different degrees and plots of (train error and test error) vs different n values.

3) For the file "ridge reg.py" you should give value of LAMBDA and DEGREE as input.Then it gives PARAMETER VALUES,TRAIN ERROR AND TEST ERROR,
   PLOT FITTING THE TRAINING DATA as output.

4) For the file "Lasso reg.py" you should give value of LAMBDA as input.Then it gives PARAMETER VALUES,TRAIN ERROR AND TEST ERROR,
   PLOT FITTING THE TRAINING DATA as output.

5) For the file "error_plot_with regularization.py" no input is required.It just gives the output of plots of (train error and test error)
   vs different lambda values for both Ridge and Lasso regression.